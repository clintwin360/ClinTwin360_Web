// New function: Do a POST (update the forms for criteria in trial_criteria.html to POST)
// Package criteria value in JSON and send to API end-point
// Wait for response
// Get data from end-point and fill table


// 1. Send {
//             "id": 1,
//             "value": "18",
//             "comparison": "gte",
//             "criteriaType": "inclusion",
//             "negated": false,
//             "criteria": 14,
//             "trial": 1
//         } to sponsor/submit_criteria/
//
// 2. Pull criteria data from here: http://127.0.0.1:8000/api/criteria_response/?trial=1

//Initial Function to test idea

var indexing = 7;

function updateForm() {
    var criteria = document.getElementById("criteria").textContent;
    // console.log(criteria);
    var value = document.getElementById("value").value;
    // console.log(value, "value");
    var comparison;

    // Check if first character in value is between 1-10
    if (value.charAt(0) == "1" || value.charAt(0) == "2" || value.charAt(0) == "3" || value.charAt(0) == "4"
      || value.charAt(0) == "5" || value.charAt(0) == "6" || value.charAt(0) == "7" || value.charAt(0) == "8"
      || value.charAt(0) == "9" || value.charAt(0) == "0"){
        comparison = document.getElementById("comparison-selected").value;
      } else { // For yes/no OR multi-select questions set comparison to "---"
        comparison = "equals";
      }
    // console.log(comparison);

    var negated = document.getElementById("negated").checked;
    // console.log(exclusion_var);

    // Create JSON object
    var formData = new Object();
    formData.id = indexing;
    formData.value = value;
    formData.comparison = indexing;

    var criteriaType;
    if (negated === true){
      criteriaType = "Exclusion";
    } else {
      criteriaType = "Inclusion";
    }
    // console.log(exclusion);
    formData.criteriaType = criteriaType;
    formData.negated = negated;
    var trial_ID = document.getElementById("criteria_trial_ID").textContent;
    formData.trial = trial_ID;

    // Get criteria_id and POST
    return get_criteria_id(criteria, formData);

}


//Used to get criteria id - not used yet
function get_criteria_id (criteria, formData) {
  console.log(formData, "passed to second function");
  // console.log(criteria); //DEBUG--
  var criteria_id;
  var currentPage = 0;
     $.getJSON("/api/criteria/", function(result){
          var pages = Math.ceil(result.count / 10);
          while (currentPage < pages){
            currentPage++;
            $.getJSON("/api/criteria/?page="+currentPage, function(result){
                $.each(result.results, function(i, field){
                    var criteria_sel = field.name;

                    if (field.searchable && (criteria_sel.localeCompare(criteria) == 0)) {
                      criteria_id = field.id;
                      console.log(criteria_id, "is criteria_id");
                      formData.criteria = criteria_id;
                      console.log(formData, "is formData");

                      //POST to API endpoint
                      return $.ajax({
                        method: 'POST',
                        url: 'https://127.0.0.1:8000/api/criteria_response/?trial=1',
                        dataType: 'json',
                        // The key needs to match your method's input parameter (case-sensitive).
                        data: JSON.stringify(formData),
                        success: function(){alert("I received the data"+formData);},
                        contentType: 'application/json; charset=utf-8',
                        failure: function(errMsg) {
                            alert(errMsg);
                        }
                      });

                      //Remove the form for the criteria
                      $('#criteria_x').remove();
                    }
                });
              });
          }
    });
}

function start_Update(criteria_id) {

}

// // Create JSON object
// $.fn.serializeObject = function(){
// var o = {};
// var a = this.serializeArray();
// $.each(a, function() {
//     if (o[this.name] !== undefined) {
//         if (!o[this.name].push) {
//             o[this.name] = [o[this.name]];
//         }
//         o[this.name].push(this.value || '');
//     } else {
//         o[this.name] = this.value || '';
//     }
// });
// console.log(o);
// return o;
// };



//
// //Initial Function to test idea
// function updateForm() {
//     var criteria = document.getElementById("comparison-0").textContent;
//     // console.log(criteria);
//     var value = document.getElementById("criteria-response-0").value;
//     // console.log(value, "value");
//     var comparison;
//
//     // Check if first character in value is between 1-10
//     if (value.charAt(0) == "1" || value.charAt(0) == "2" || value.charAt(0) == "3" || value.charAt(0) == "4"
//       || value.charAt(0) == "5" || value.charAt(0) == "6" || value.charAt(0) == "7" || value.charAt(0) == "8"
//       || value.charAt(0) == "9" || value.charAt(0) == "0"){
//         comparison = document.getElementById("comparison-selected").value;
//       } else { // For yes/no OR multi-select questions set comparison to "---"
//         comparison = "=";
//       }
//     // console.log(comparison);
//
//     var exclusion_var = document.getElementById("negation-maker").checked;
//     // console.log(exclusion_var);
//     var exclusion;
//     if (exclusion_var === true){
//       exclusion = "Exclusion";
//     } else {
//       exclusion = "Inclusion";
//     }
//     // console.log(exclusion);
//
//     var table=document.getElementById("criteria-table");
//     var row=table.insertRow(-1);
//     var criteria_col=row.insertCell(0);
//     var value_col=row.insertCell(1);
//     var comparison_col=row.insertCell(2);
//     var exclusion_col=row.insertCell(3);
//     criteria_col.innerHTML=criteria;
//     value_col.innerHTML=value;
//     comparison_col.innerHTML=comparison;
//     exclusion_col.innerHTML=exclusion;
//
//     //Remove the form for the criteria
//     $('#criteria_x').remove();
//
// }
