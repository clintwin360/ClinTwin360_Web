$(function(){
    if (hide){
        document.getElementById('div_id_sponsor').style.display = 'none';
    }
});
