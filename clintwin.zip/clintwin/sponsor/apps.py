from django.apps import AppConfig


class SponsorConfig(AppConfig):
    name = 'sponsor'
