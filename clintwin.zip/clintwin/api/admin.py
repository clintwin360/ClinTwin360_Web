from django.contrib import admin
import sponsor
from sponsor.models import *
# Register your models here.

"""
admin.site.register(Participant)
admin.site.register(ParticipantResponse)
admin.site.register(ClinicalTrial)
admin.site.register(Sponsor)
admin.site.register(SponsorRequest)
admin.site.register(ClinicalTrialCriteriaResponse)
admin.site.register(QuestionCategory)
"""